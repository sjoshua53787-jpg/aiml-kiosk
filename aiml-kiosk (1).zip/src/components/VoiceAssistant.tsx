"use client";
import { useEffect, useRef, useState } from "react";

export default function VoiceAssistant() {
  const [listening, setListening] = useState(false);
  const recogRef = useRef<SpeechRecognition | null>(null);

  useEffect(() => {
    const SR: any = window.webkitSpeechRecognition || window.SpeechRecognition;
    if (SR) {
      const recog = new SR();
      recog.lang = "en-IN";
      recog.onresult = (e: any) => {
        const said = e.results[0][0].transcript;
        speak(`You asked about ${said}. Admissions help is my priority.`);
      };
      recog.onend = () => setListening(false);
      recogRef.current = recog;
    }
  }, []);

  const startListening = () => {
    recogRef.current?.start();
    setListening(true);
  };

  const speak = (text: string) => {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    const voice = speechSynthesis.getVoices().find(v => v.lang.includes("en"));
    if (voice) u.voice = voice;
    speechSynthesis.speak(u);
  };

  return (
    <div>
      <button onClick={startListening}>
        {listening ? "Listening..." : "Tap to Speak"}
      </button>
    </div>
  );
}
