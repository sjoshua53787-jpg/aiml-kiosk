"use client";
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from "recharts";
import data from "../data/placements.json";

export default function PlacementsCharts() {
  return (
    <div>
      <BarChart width={500} height={300} data={data}>
        <XAxis dataKey="year" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Bar dataKey="placed" fill="#8884d8" />
        <Bar dataKey="total_offers" fill="#82ca9d" />
      </BarChart>
    </div>
  );
}
