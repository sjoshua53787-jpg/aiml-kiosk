export default function Admissions() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Admissions</h1>
      <p>Fill in your application form here (form logic to be added).</p>
    </div>
  );
}