import PlacementsCharts from "../components/PlacementsCharts";

export default function Placements() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Placements</h1>
      <PlacementsCharts />
    </div>
  );
}