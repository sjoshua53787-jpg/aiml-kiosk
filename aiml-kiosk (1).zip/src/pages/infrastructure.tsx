export default function Infrastructure() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Infrastructure</h1>
      <p>Photo gallery of labs and facilities will be here.</p>
    </div>
  );
}