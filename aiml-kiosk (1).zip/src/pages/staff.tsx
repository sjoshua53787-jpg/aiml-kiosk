export default function Staff() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Staff Directory</h1>
      <p>Staff cards will be displayed here.</p>
    </div>
  );
}