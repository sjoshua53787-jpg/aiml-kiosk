import Link from "next/link";

export default function Home() {
  return (
    <main className="p-8 text-center">
      <h1 className="text-3xl font-bold">AIML Dept Kiosk</h1>
      <nav className="grid gap-4 mt-8">
        <Link href="/admissions">Admissions</Link>
        <Link href="/staff">Staff Directory</Link>
        <Link href="/infrastructure">Infrastructure</Link>
        <Link href="/placements">Placements</Link>
        <Link href="/faq">FAQ & Voice Assistant</Link>
      </nav>
    </main>
  );
}
